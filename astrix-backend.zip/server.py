from fastapi import FastAPI
from pydantic import BaseModel
from astrix import run_astrix

app = FastAPI()

class Query(BaseModel):
    query: str

@app.post("/run")
def run_agent(q: Query):
    return {"reply": run_astrix(q.query)}
