import os
from openai import OpenAI

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

ASTRIX_SYSTEM_PROMPT = """You are ASTRIX, an autonomous engineer...""" 

def run_astrix(message: str) -> str:
    resp = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role":"system","content":ASTRIX_SYSTEM_PROMPT},
            {"role":"user","content": message}
        ]
    )
    return resp.choices[0].message.content
